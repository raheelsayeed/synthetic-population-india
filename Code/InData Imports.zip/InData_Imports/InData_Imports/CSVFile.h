//
//  CSVFile.h
//  InData_Imports
//
//  Created by Raheel Sayeed on 6/11/16.
//  Copyright © 2016 Raheel Sayeed. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CHCSVParser.h"


@interface CSVFile : NSObject

@property (nonatomic) CHCSVParser * parser;
@property (nonatomic, readonly) NSString * filename;
@property (nonatomic) NSString * filepath;
@property (nonatomic) NSDictionary * columnHeaders;

- (instancetype) initWithFilePath:(NSString *)filepath;
- (void)parse;
- (NSString *)dataFromRow:(NSUInteger)row column:(NSUInteger)column;
- (NSString *)dataFromRow:(NSUInteger)row header:(NSString *)headerKey;
@end
