//
//  CSVFile.m
//  InData_Imports
//
//  Created by Raheel Sayeed on 6/11/16.
//  Copyright © 2016 Raheel Sayeed. All rights reserved.
//

#import "CSVFile.h"
#import "CSVDelegate.h"
#import "CHCSVParser.h"

@interface CSVFile ()
@property (nonatomic) CSVDelegate * parserDelegate;
@end

@implementation CSVFile

- (instancetype) initWithFilePath:(NSString *)filepath
{
    self  = [super init];
    if(self)
    {
        NSURL * fileURL = [NSURL fileURLWithPath:filepath];
        self.parserDelegate = [[CSVDelegate alloc] init];
        self.parser  = [[CHCSVParser alloc] initWithContentsOfCSVURL:fileURL];
        self.parser.delegate = self.parserDelegate;
    }
    return self;
}

- (void)parse
{
    if(![_parserDelegate lines])
    {
        [_parser parse];
    }
}

- (NSString *)dataFromRow:(NSUInteger)row column:(NSUInteger)column
{
    return _parserDelegate.lines[row][column];
}


- (NSString *)dataFromRow:(NSUInteger)row header:(NSString *)headerKey
{
    if(!_columnHeaders || !_columnHeaders[headerKey]) return nil;
    NSNumber * n = _columnHeaders[headerKey];
    return [self dataFromRow:row column:n.unsignedIntegerValue];
}




@end