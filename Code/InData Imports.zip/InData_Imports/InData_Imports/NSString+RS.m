//
//  NSString+RS.m
//  InData_Imports
//
//  Created by Raheel Sayeed on 6/16/16.
//  Copyright © 2016 Raheel Sayeed. All rights reserved.
//

#import "NSString+RS.h"


static NSString * const kIndianDataFolder = @"/Users/raheelsayeed/Desktop/Synth_India Projects/India-DataFiles";

@implementation NSString (RS)

- (NSString *)IDF_filepath
{
    return [kIndianDataFolder stringByAppendingPathComponent:self];
}

@end
