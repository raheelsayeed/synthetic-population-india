//
//  main.m
//  InData_Imports
//
//  Created by Raheel Sayeed on 6/11/16.
//  Copyright © 2016 Raheel Sayeed. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CHCSVParser.h"
#import "CSVDelegate.h"
#import "CSVFile.h"
#import "NSString+RS.h"
#import "IPF.h"
#import "PopulationSetBuilder.h"

// log(@"%@", [IPF runIPF]);
//
NSArray * arrayForCSV(NSString * fileName)
{
    NSURL * fileURL = [NSURL fileURLWithPath:[fileName IDF_filepath]];
    return [NSArray arrayWithContentsOfCSVURL:fileURL options:CHCSVParserOptionsUsesFirstLineAsKeys];
}

void files(){
    NSString * filename;
    filename = @"census_test.csv";
    
    log(@"file=%@ %@", filename, arrayForCSV(filename)[200]);
    
    filename = @"Urban-28-codes.CSV";
    log(@"file=%@ %@", filename, arrayForCSV(filename)[234]);
    
    filename = @"Rural-28-codes.CSV";
    log(@"file=%@ %@", filename, arrayForCSV(filename)[542]);
    
    filename = @"RangaReddy_Blockwise_hh_pop_ur.csv";
    log(@"file=%@ %@", filename, arrayForCSV(filename)[234]);
    
    filename = @"HH_pop_size_urban_rural.csv";
    log(@"file=%@ %@", filename, arrayForCSV(filename)[232]);
    
    filename = @"District_area_population.csv";
    log(@"file=%@ %@", filename, arrayForCSV(filename)[345]);
    
    
    filename = @"PCA_AY_2011_Revised.csv";
    log(@"file=%@ %@", filename, arrayForCSV(filename)[345]);
}

void database_procs()
{
    log(@"PopulationBuilder ret:l %@", [PopulationSetBuilder run]);
}


int main(int argc, const char * argv[]) {
    @autoreleasepool {

     
        [PopulationSetBuilder run];
        
        
    }
    return 0;
    
    
    
    
}



















