//
//  NSArray+RS.h
//  InData_Imports
//
//  Created by Raheel Sayeed on 6/18/16.
//  Copyright © 2016 Raheel Sayeed. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (RS)

- (NSArray *)transposedTwoDArray;

@end
