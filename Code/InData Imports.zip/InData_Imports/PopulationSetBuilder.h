//
//  PopulationSetBuilder.h
//  InData_Imports
//
//  Created by Raheel Sayeed on 6/20/16.
//  Copyright © 2016 Raheel Sayeed. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PopulationSetBuilder : NSObject
+(id)run;
@end
